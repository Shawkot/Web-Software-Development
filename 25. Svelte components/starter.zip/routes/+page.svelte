<script>
  import Location from "$lib/components/Location.svelte";
  import Movement from "$lib/components/Movement.svelte";
</script>

<Location />
<Movement />
